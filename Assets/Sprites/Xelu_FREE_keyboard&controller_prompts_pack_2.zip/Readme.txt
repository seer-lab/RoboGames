Hey there!

Hope you make good use of this pack. You can use all the images provided in any project you want to (be it commercial or not).

In this pack you will find over 380 buttons ranging from 

Touch screen gestures
PS Vita
Xbox 360 controller
Xbox One controller
Play Station 3 controller
Play Station 4 controller
Wii controller
Wii U controller
Steam controller (Both prototypes including touch pad and quad buttons)
Ouya
Keyboard and mouse buttons (Both in black and white including blanks)
Directional arrows for thumb sticks and movement keys


I am "Nicolae Berbece" (also known as Xelu) and you can find me at nick@thoseawesomeguys.com or xelubest.com

Feel free to credit me in case you use anything in this pack, but don't worry, I don't mind if you won't. :)

Please share this pack with other fellow developers in need of such assets! 
Keep being awesome!

~Nick